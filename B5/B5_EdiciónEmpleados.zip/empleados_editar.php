<?php
// Este archivo solo debe procesar peticiones POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: empleados_lista.php');
    exit;
}

include "db_connect.php";

// Verificar que la conexión funciona y que se recibieron todos los datos
if ($conn && isset($_POST['id'], $_POST['nombre'], $_POST['apellidos'], $_POST['correo'], $_POST['rol'])) {
    
    $id = intval($_POST['id']);
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $correo = $_POST['correo'];
    $rol = $_POST['rol'];
    $pass = isset($_POST['pass']) ? $_POST['pass'] : '';
    
    // Verificar que el empleado existe y está activo
    $sql_check = "SELECT id FROM empleados WHERE id = $id AND eliminado = 0";
    $result_check = $conn->query($sql_check);
    
    if (!$result_check || $result_check->num_rows == 0) {
        echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>";
        echo "<title>Error</title><link rel='stylesheet' href='estilos.css'></head><body>";
        echo "<div class='mensaje error'>";
        echo "<h2>Error al actualizar</h2>";
        echo "<p>El empleado no existe o está inactivo.</p>";
        echo "<p><a href='empleados_lista.php' class='button'>Volver al Listado</a></p>";
        echo "</div></body></html>";
        $conn->close();
        exit;
    }
    
    // Construir la consulta UPDATE
    // Si se proporcionó contraseña, incluirla en la actualización
    if (!empty($pass) && trim($pass) !== '') {
        $sql = "UPDATE empleados 
                SET nombre = '$nombre', apellidos = '$apellidos', correo = '$correo', 
                    rol = $rol, pass = '$pass' 
                WHERE id = $id AND eliminado = 0";
    } else {
        // No actualizar la contraseña
        $sql = "UPDATE empleados 
                SET nombre = '$nombre', apellidos = '$apellidos', correo = '$correo', rol = $rol 
                WHERE id = $id AND eliminado = 0";
    }
    
    if ($conn->query($sql) === TRUE) {
        // Éxito: redirigir a la lista de empleados
        $conn->close();
        header('Location: empleados_lista.php');
        exit;
    } else {
        // Error en el UPDATE
        $error_msg = $conn->error;
        
        // Traducir errores comunes de MySQL al español
        if (strpos($error_msg, "Duplicate entry") !== false) {
            // Extraer el valor duplicado y el campo
            preg_match("/Duplicate entry '([^']+)' for key '([^']+)'/", $error_msg, $matches);
            if (count($matches) >= 3) {
                $valor = $matches[1];
                $campo = $matches[2];
                $error_msg = "Entrada duplicada '$valor' para el campo '$campo'";
            } else {
                $error_msg = "El correo electrónico ya está registrado en el sistema";
            }
        }
        
        echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>";
        echo "<title>Error</title><link rel='stylesheet' href='estilos.css'></head><body>";
        echo "<div class='mensaje error'>";
        echo "<h2>Error al actualizar empleado</h2>";
        echo "<p>" . htmlspecialchars($error_msg) . "</p>";
        echo "<p><a href='empleados_editar_form.php?id=$id' class='button'>Volver al Formulario</a></p>";
        echo "</div></body></html>";
        $conn->close();
        exit;
    }
    
} else {
    echo "<!DOCTYPE html><html lang='es'><head><meta charset='UTF-8'>";
    echo "<title>Error</title><link rel='stylesheet' href='estilos.css'></head><body>";
    echo "<div class='mensaje error'>";
    echo "<p>No se recibieron todos los datos del formulario</p>";
    echo "<p><a href='empleados_lista.php' class='button'>Volver al Listado</a></p>";
    echo "</div></body></html>";
    if ($conn) $conn->close();
    exit;
}
