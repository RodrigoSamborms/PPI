<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Productos</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <?php include "menu.php"; ?>
    
    <div class="bienvenido-container">
        <h1>Productos</h1>
        <div class="mensaje" style="background-color: #fff3cd; border-left: 4px solid #ffc107; color: #856404;">
            <h2>🚧 En Construcción 🚧</h2>
            <p>Esta sección está actualmente en desarrollo.</p>
            <p>Próximamente podrás gestionar el catálogo de productos desde aquí.</p>
        </div>
    </div>
</body>
</html>
