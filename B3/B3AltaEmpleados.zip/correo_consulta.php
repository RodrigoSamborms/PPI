<?php
include "db_connect.php";

// Verificar que se recibió el correo
if (isset($_POST['correo']) && !empty($_POST['correo'])) {
    $correo = $_POST['correo'];
    
    // Consultar si el correo ya existe
    $sql = "SELECT COUNT(*) as total FROM empleados WHERE correo = '$correo' AND eliminado = 0";
    $result = $conn->query($sql);
    
    if ($result) {
        $row = $result->fetch_assoc();
        if ($row['total'] > 0) {
            echo "1"; // Correo existe
        } else {
            echo "0"; // Correo no existe
        }
    } else {
        echo "0"; // Error en consulta, permitir continuar
    }
} else {
    echo "0"; // No se recibió correo, permitir continuar
}

$conn->close();
